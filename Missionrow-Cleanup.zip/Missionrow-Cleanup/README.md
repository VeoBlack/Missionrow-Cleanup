# missonrow-cleanup
 Installation guide:
1. download the ZIP file.
2. unpack the folder contained there (Missionrow-Cleanup).
3. drag it into your resource folder
4. go to your server.cfg and write: "Ensure Missionrow-Cleanup".



Now the Ymap is ready to use :)
Have fun!
