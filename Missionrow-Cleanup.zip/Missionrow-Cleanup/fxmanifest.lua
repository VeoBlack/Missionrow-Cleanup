fx_version 'bodacious'
games { 'rdr3', 'gta5' }

this_is_a_map 'yes'